/* ================================================================
 * Beispiele f�r den Zugriff auf Datenbanken aus JAVA-basierten
 * Internetanwendungen
 *                                       Bernhard Schiefer (07/2022)
 * ================================================================ */
 
Die in diesem Archiv enthaltenen Programme dienen als Beispiele 
f�r erste Zugriffe auf die Uebungsdatenbank von Internetanwendungen
aus.

Die Verbindungsinformationen (DB-Name, Benutzer, Passwort)
in der Datei "db_*.properties" m�ssen ebenfalls jeweils angepasst werden.
Verzeichnis: src/properties

Beispiele f�r MariaDB, MaxDB, MySQL, ORACLE und PostgreSQL sind beigef�gt.

Achtung: Die genutzen Dateien muessen sich im Classpath (classes)
befinden, damit es funktioniert.

Denken Sie daran, dass Sie bei Verwendung einer lokalen MySQL-DB diese 
zuerst �ber XAMPP starten m�ssen.

In den Ordner /lib des verwendeten Tomcat-Servers m�ssen Sie alle ben�tigten Libs 
- wie z.B. den jdbc-Treiber der Datenbank - vor den ersten Start kopieren.