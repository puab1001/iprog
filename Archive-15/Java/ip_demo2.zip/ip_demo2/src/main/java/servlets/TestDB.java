package servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;

import db.DBConnect;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/TestDB")
public class TestDB extends HttpServlet {
  private static final long serialVersionUID = 1L;

  @Override
  protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    boolean ok = false;
    String zeit = "";
    try (Connection cn = DBConnect.connect()) {
      if (cn != null) {
        System.out.println("DB-Verbindung ok!");
        ok = true;

        try (ResultSet rs = cn.createStatement().executeQuery("SELECT current_time FROM dual")) {
          if (rs.next()) {
            zeit = "Serverzeit ist : " + rs.getString("current_time");
          }
        }
      } else
        System.out.println("Keine DB-Verbindung erhalten!");
    } catch (Exception e) {
      System.err.println("Es ging was schief : " + e);
    }
    
    PrintWriter out = response.getWriter(); // zur Erstellung der HTML-Ausgabe
    out.println("<html>");
    out.println("<head><title>Servlet1</title></head>");
    out.println("<link rel='stylesheet' type='text/css' href='css/styles.css' />");
    out.println("<body>");
    out.append("<p>DB-Verbindung Ok? &rarr; " + ok + "</p>");
    out.append("<p>Server-Zeit : " + zeit + "</p>");
    out.println("</body></html>");
  }
}
