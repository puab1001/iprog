package servlets;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import db.DBConnect;
import db.ProductDB;
import db.Product;

@WebServlet("/controller")
public class Controller extends HttpServlet {
  private static final long serialVersionUID = 1L;

  @Override
  public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    String param = request.getParameter("kname");
    System.out.println("service ENTER mit kname=" + param);
    
    String nextPage = "Fehlerbehandlung.jsp";
    
    if (param == null) {
      request.setAttribute("fehlertext", "Kein Wert für Parameter 'kname' übergeben!");
    } else {
      List<Product> products = null;
      
      try (Connection cn = DBConnect.connect()) {

        products = "all".equals(param) ? ProductDB.findAll(cn)
                                       : ProductDB.findByCategoryid(cn, param);
      } catch (SQLException e) {
        System.err.println("SQL-Fehler " + e);
        request.setAttribute("fehlertext", e);
      }
      
      request.setAttribute("produkte", products);
      request.setAttribute("kname", param);
      nextPage = "View.jsp";
    }
    request.getRequestDispatcher(nextPage).forward(request, response);
  }
}
