package servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.util.List;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import db.DBConnect;
import db.ProductDB;
import db.Product;

@WebServlet("/DirekteAusgabe")
public class DirekteAusgabe extends HttpServlet {
  private static final long serialVersionUID = 1L;
  private static final String CONTENT_TYPE = "text/html; charset=UTF-8";

  @Override
  public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    response.setContentType(CONTENT_TYPE);
    PrintWriter out = response.getWriter();
    out.println("<!DOCTYPE html");
    out.println("<html>");
    out.println("<head><title>Direkte Ausgabe</title>");
    out.println("<link type='text/css' rel='stylesheet' href='css/styles.css'/>");
    out.println("</head>");
    out.println("<body>");

    String param = request.getParameter("kname");
    if (param == null) {
      out.println("<p>kname == null &rarr; Nichts ausgewählt! Parameter 'kname' angeben.</p>");
    } else {
      List<Product> products = null;
      
      try (Connection cn = DBConnect.connect()) {

        products = "all".equals(param) ? ProductDB.findAll(cn)
                                       : ProductDB.findByCategoryid(cn, param);
      } catch (Exception e) {
        System.err.println("Es ging was schief: " + e);
      }
      
      out.println("<table>"); // Tabelle ausgeben
      out.println("<tr><th>Kategorie</th><th>Name</th><th>Beschreibung</th><th>Foto</th></tr>");
      
      if (products != null) {
        for (Product p : products) {
          out.println("<tr>"
                    + "  <td>" + p.getCategoryid() + "</td>" 
                    + "  <td>" + p.getName() + "</td>" 
                    + "  <td>" + p.getDescription() + "</td>"
                    + "  <td><img src='images/" + p.getImageurl() + "'/></td>"
                    + "</tr>");
        }
      }
      out.println("</table>");
    }
    out.println("</body></html>");
    out.close();
  }
}
