package db;

import java.io.Serializable;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Product implements Serializable {
  private static final long serialVersionUID = 1L;
  
  private String productid;
  private String categoryid;
  private String name;
  private String description;
  private String imageurl;

  @Override
  public String toString() {
    return "[productid=" + productid + ", categoryid=" + categoryid
        + ", name=" + name + ", description=" + description + ", imageurl=" + imageurl + "]";
  }

  public Product(String productid, String categoryid, String name, String description, String imageurl) {
    super();
    this.productid = productid;
    this.categoryid = categoryid;
    this.name = name;
    this.description = description;
    this.imageurl = imageurl;
  }

  public Product(ResultSet rset) throws SQLException {
    this (rset.getString("productid"), rset.getString("categoryid"),
          rset.getString("name"), rset.getString("description"), rset.getString("imageurl"));
  }

  // ================ Ab hier nur generierte getter/setter ================

  public String getProductid() {
    return productid;
  }

  public void setProductid(String productid) {
    this.productid = productid;
  }

  public String getCategoryid() {
    return categoryid;
  }

  public void setCategoryid(String categoryid) {
    this.categoryid = categoryid;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public String getDescription() {
    return description;
  }

  public void setDescription(String description) {
    this.description = description;
  }

  public String getImageurl() {
    return imageurl;
  }

  public void setImageurl(String imageurl) {
    this.imageurl = imageurl;
  }
}
