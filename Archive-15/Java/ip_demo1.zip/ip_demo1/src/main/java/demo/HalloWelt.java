package demo;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet("/HalloWelt")
public class HalloWelt extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter writer = response.getWriter();
		response.setContentType("text/html; charset=ISO-8859-1");
		
		String p = request.getParameter("p");
		
    Object p_alt = request.getSession().getAttribute("p_alt");

    if (p != null) {
		  request.getSession().setAttribute("p_alt", p);
		}
		
		System.out.println("Der Parameter p=" + p);
		
		writer.append("<p>Hallo Welt!</p>");
		writer.append("<p>p =" + p + "</p>");
    writer.append("<p>p_alt =" + p_alt + "</p>");
	}

}
