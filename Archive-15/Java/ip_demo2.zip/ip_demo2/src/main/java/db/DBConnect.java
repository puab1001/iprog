package db;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.util.Properties;

public class DBConnect {

  private static final String DEFAULT_CONNECTION_TYPE = "mariadb";

  public static Connection connect() {
    return connect(DEFAULT_CONNECTION_TYPE);
  }

  public static Connection connect(String dbtype) {
    final String propfile = "/properties/db_" + dbtype + ".properties";

    System.out.println("DBConnect.connect dbtype=" + dbtype);
    Connection cn = null;
    try {
      final java.io.InputStream propFile = DBConnect.class.getResourceAsStream(propfile);
      final Properties props = new Properties();
      props.load(propFile);

      // Class.forName(props.getProperty("driver"));

      final String url = props.getProperty("url");
      final String usr = props.getProperty("user");
      final String pwd = props.getProperty("password");

      cn = DriverManager.getConnection(url, usr, pwd);

    } catch (Exception e) {
      System.err.println("DBConnect.connect: Problem : " + e.toString());
    }
    return cn;
  }

	public static void main(String[] args) {
		System.out.println("=====> START <=====");

		try (Connection cn = DBConnect.connect()) {
			if (cn != null) {
				System.out.println("------------------------------------");
				DatabaseMetaData dbMetaData = cn.getMetaData();
				System.out.println("Datenbankname    : " + dbMetaData.getDatabaseProductName());
				System.out.println("Datenbankversion : " + dbMetaData.getDatabaseProductVersion());
				System.out.println("Treiberversion   : " + dbMetaData.getDriverVersion());
				System.out.println("JDBCMajorVersion : " + dbMetaData.getJDBCMajorVersion());
				System.out.println("JDBCMinorVersion : " + dbMetaData.getJDBCMinorVersion());
				System.out.println("------------------------------------");
			}
		} catch (Exception e) {
			System.err.println("Etwas ging schief!");
			e.printStackTrace();
		}
		System.out.println("=====> FERTIG <=====");
	}
}
