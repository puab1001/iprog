package db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.LinkedList;
import java.util.List;

public class ProductDB {

  public static List<Product> findAll(Connection cn) {
    System.out.println ("ProductDB.findAll");
    List<Product> erg = new LinkedList<>();

    String sql = "SELECT * FROM Product";
    try (Statement stmt = cn.createStatement();
         ResultSet rset = stmt.executeQuery(sql)) {
      
      while (rset.next()) {
        erg.add(new Product(rset));
      }
    } catch (SQLException e) {
      System.err.println("Ein DB-Fehler ist aufgetreten:" + e.toString());
    }
    return erg;
  }

  public static List<Product> findByCategoryid(Connection cn, String id) {
    System.out.println("ProductDB.findByCategoryid ENTER id=" + id);
    
    List<Product> erg = new LinkedList<>();

    String sql = "SELECT * FROM Product WHERE categoryid = ?";

    try (PreparedStatement pstmt = cn.prepareStatement(sql)) {
      pstmt.setString(1, id);
      try (ResultSet rset = pstmt.executeQuery()) {
        while (rset.next()) {
          erg.add(new Product(rset));
        }
      }
    } catch (SQLException e) {
      System.err.println("Ein DB-Fehler ist aufgetreten:" + e + "\n" + sql);
    }
    return erg;
  }

  public static int insert(Connection cn, Product dto) throws SQLException {
    System.out.println("ProductDB.insert ENTER dto=" + dto);
    
    int ergebnis = 0;
    
    String sql = "INSERT INTO Product (productid, categoryid, name, description, imageurl)"
              + " VALUES (?, ?, ?, ?, ?)";

    try (PreparedStatement pstmt = cn.prepareStatement(sql)) {
      // TODO
      ergebnis = pstmt.executeUpdate();
    } catch (SQLException e) {
      System.err.println("Ein DB-Fehler ist aufgetreten:" + e + "\n" + sql);
    }
    return ergebnis;
  }

  public static int update (Connection cn, Product dto) throws SQLException {
    System.out.println ("ProductDB.update ENTER dto="+dto);
    // TODO
    return 0;
  }
  
  public static int delete(Connection cn, String productid) throws SQLException {
    System.out.println("ProductDB.delete ENTER productid=" + productid);
    // TODO
    return 0;
  }
}
