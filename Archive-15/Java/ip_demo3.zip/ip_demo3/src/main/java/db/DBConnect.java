package db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.util.Properties;

public class DBConnect{
  final static String propfile = "/properties/db.properties";
  
  public static Connection connect() {

    Connection cn = null;
    try {
      final java.io.InputStream propFile = DBConnect.class.getResourceAsStream(propfile);
      final Properties props = new Properties();
      props.load(propFile);

      final String url = props.getProperty("url");
      final String usr = props.getProperty("user");
      final String pwd = props.getProperty("password");

      cn = DriverManager.getConnection(url, usr, pwd);
      System.out.println("DBConnect.connect DB-Typ=" + cn.getMetaData().getDatabaseProductName());

    } catch (Exception e) {
      System.err.println("DBConnect.connect: Problem : " + e.toString());
    }
    return cn;
  }
}
