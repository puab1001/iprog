package db;

import java.sql.ResultSet;
import java.sql.SQLException;

public class DemoDTO {
  private int id;
  private String name;
  private boolean available;
  
  public DemoDTO(ResultSet rs) throws SQLException {
    super();
    this.id = rs.getInt("id");
    this.name = rs.getString("name");
    this.available = rs.getBoolean("available");
  }
  
  // ==================== generierte Methoden =================
  
  public DemoDTO(int id, String name, boolean available) {
    super();
    this.id = id;
    this.name = name;
    this.available = available;
  }

  public int getId() {
    return id;
  }
  public void setId(int id) {
    this.id = id;
  }
  public String getName() {
    return name;
  }
  public void setName(String name) {
    this.name = name;
  }
  public boolean isAvailable() {
    return available;
  }
  public void setAvailable(boolean available) {
    this.available = available;
  }

  
}
