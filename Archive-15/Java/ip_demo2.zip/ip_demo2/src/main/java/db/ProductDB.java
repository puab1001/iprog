package db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.LinkedList;
import java.util.List;

public class ProductDB {

  public static List<ProductDTO> findAll(Connection cn) {
    System.out.println ("ProductDB.findAll");
    List<ProductDTO> erg = new LinkedList<>();

    String sql = "SELECT * FROM Product";
    try (Statement stmt = cn.createStatement();
         ResultSet rset = stmt.executeQuery(sql)) {
      
      while (rset.next()) {
        erg.add(new ProductDTO(rset));
      }
    } catch (SQLException e) {
      System.err.println("Ein DB-Fehler ist aufgetreten:" + e.toString());
    }
    return erg;
  }

  public static List<ProductDTO> findByCategoryid(Connection cn, String id) {
    System.out.println("ProductDB.findByCategoryid mit id=" + id);
    
    String sql = "SELECT * FROM Product WHERE categoryid = ?";
    List<ProductDTO> erg = new LinkedList<>();

    try (PreparedStatement pstmt = cn.prepareStatement(sql)) {
      pstmt.setString(1, id);
      
      try (ResultSet rset = pstmt.executeQuery()) {
        while (rset.next()) {
          erg.add(new ProductDTO(rset));
        }
      }
    } catch (SQLException e) {
      System.err.println("Ein DB-Fehler ist aufgetreten:" + e + "\n" + sql);
    }
    return erg;
  }

  public static int insert(Connection cn, ProductDTO dto) throws SQLException {
    System.out.println("ProductDB.insert mit dto=" + dto);
    
    String sql = "INSERT INTO Product (productid, categoryid, name, description, imageurl)"
              + " VALUES (?, ?, ?, ?, ?)";
    
    int ergebnis = 0;
    try (PreparedStatement pstmt = cn.prepareStatement(sql)) {
      // TODO : Parameter setzen, ...
      ergebnis = pstmt.executeUpdate();
    } catch (SQLException e) {
      System.err.println("Ein DB-Fehler ist aufgetreten:" + e + "\n" + sql);
    }
    return ergebnis;
  }

  public static int update(Connection cn, ProductDTO dto) throws SQLException {
    System.out.println("ProductDB.update mit dto=" + dto);
    // TODO
    return 0;
  }
  
  public static int delete(Connection cn, String productid) throws SQLException {
    System.out.println("ProductDB.delete mit productid=" + productid);
    // TODO
    return 0;
  }
}
