package db;

import java.sql.ResultSet;
import java.sql.SQLException;

public class ProductDTO {
  private String productid;
  private String categoryid;
  private String name;
  private String description;
  private String imageurl;

  @Override
  public String toString() {
    return "ProductDTO [productid=" + productid + ", categoryid=" + categoryid
                   + ", name=" + name + ", description=" + description
                   + ", imageurl=" + imageurl+ "]";
  }
  
  public ProductDTO() {  }

  public ProductDTO(String productid, String categoryid, String name, String description, String imageurl) {
    super();
    this.productid = productid;
    this.categoryid = categoryid;
    this.name = name;
    this.description = description;
    this.imageurl = imageurl;
  }

  public ProductDTO(ResultSet rset) {
    try {
      productid   = rset.getString("productid");
      categoryid  = rset.getString("categoryid");
      name        = rset.getString("name");
      description = rset.getString("description");
      imageurl    = rset.getString("imageurl");
    } catch (SQLException e) {
      System.err.println("Ein DB-Fehler ist aufgetreten:" + e.toString());
    }
  }
  
  // ================ Ab hier nur getter/setter ================

  public String getProductid() {
    return productid;
  }

  public void setProductid(String productid) {
    this.productid = productid;
  }

  public String getCategoryid() {
    return categoryid;
  }

  public void setCategoryid(String categoryid) {
    this.categoryid = categoryid;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public String getDescription() {
    return description;
  }

  public void setDescription(String description) {
    this.description = description;
  }

  public String getImageurl() {
    return imageurl;
  }

  public void setImageurl(String imageurl) {
    this.imageurl = imageurl;
  }


}
